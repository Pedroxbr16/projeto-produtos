package Telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Window.Type;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Seleção extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Seleção frame = new Seleção();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Seleção() {
		setResizable(false);
		setType(Type.UTILITY);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 397, 234);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(146, 187, 219));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox txtcategoria = new JComboBox();
		txtcategoria.setModel(new DefaultComboBoxModel(new String[] {"", "Higiene", "Padaria", "Carnes", "Limpeza", "Bebidas", "Utilidades ", "Frios ", "Laticíneos", "Mercearia"}));
		txtcategoria.setBounds(108, 95, 127, 22);
		contentPane.add(txtcategoria);
		
		JLabel lblNewLabel = new JLabel("Selecione a Categoria do Produto");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(67, 49, 218, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Selecionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String categoria = txtcategoria.getSelectedItem().toString();
				
				
				if(categoria.equals("Higiene")  ) {
                	
                	
                	
					ListagemHigiene pedidos = new ListagemHigiene();
                	
                	pedidos.setVisible(true);
	                pedidos.setLocationRelativeTo(null);
	                setVisible(false);
	                
                	
            	
	                
            		}//FIMSE
					
				else if(categoria.equals("Padaria")){
					
					ListagemPadaria abrir = new ListagemPadaria();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
				}else if(categoria.equals("Carnes")){
					
					ListagemCarnes abrir = new ListagemCarnes();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
					
				}else if(categoria.equals("Limpeza")){
					
					ListagemLimpeza abrir = new ListagemLimpeza();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
				}else if(categoria.equals("Bebidas")){
					
					ListagemBebidas abrir = new ListagemBebidas();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
				}else if(categoria.equals("Utilidades")){
					
					ListagemUtilidades abrir = new ListagemUtilidades();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
				}else if(categoria.equals("Frios")){
					
					ListagemFrios abrir = new ListagemFrios();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
				}else if(categoria.equals("Laticíneos")){
					
					ListagemLaticineos abrir = new ListagemLaticineos();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
					
					
				}else if(categoria.equals("Mercearia")){
					
					ListagemMercearia abrir = new ListagemMercearia();
					
					abrir.setVisible(true);
					abrir.setLocationRelativeTo(null);
					setVisible(false);
					
					
				}
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			}

			private void elseif(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(120, 151, 104, 23);
		contentPane.add(btnNewButton);
	}
}
