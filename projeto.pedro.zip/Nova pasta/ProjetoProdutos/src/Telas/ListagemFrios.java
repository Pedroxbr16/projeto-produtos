package Telas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class ListagemFrios extends JFrame {
   public ListagemFrios() {
   	setResizable(false);
       setTitle("Tabela de Frios");
       setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       // Criar um modelo de tabela padrão
       DefaultTableModel modeloTabela = new DefaultTableModel();
       // Adicionar colunas ao modelo de tabela
       modeloTabela.addColumn("codigo");
       modeloTabela.addColumn("nome");
       modeloTabela.addColumn("quantidade");
       modeloTabela.addColumn("codigo de barras");
       modeloTabela.addColumn("fornecedor");
       modeloTabela.addColumn("validade");
       // Adicione mais colunas conforme necessário
       try {
           // Conectar ao banco de dados
           Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/projeto", "root", "alunolab");
           // Preparar e executar a consulta SQL
           PreparedStatement consulta = conexao.prepareStatement("SELECT * FROM produtos WHERE categoria = ?");
           consulta.setString(1, "Frios");
           ResultSet resultado = consulta.executeQuery();
           // Processar os resultados e preencher a tabela
           while (resultado.next()) {
               modeloTabela.addRow(new Object[]{
                   resultado.getString("codigo"),
                   resultado.getString("nome"),
                   resultado.getString("quantidade"),
                   resultado.getString("codbarras"),
                   resultado.getString("fornecedor"),
                   resultado.getString("validade")
                   
                   // Adicione mais colunas conforme necessário
               });
           }
           // Fechar a conexão com o banco de dados
           conexao.close();
       } catch (SQLException e) {
           e.printStackTrace();
           JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados");
       }
       // Criar uma JTable com o modelo de tabela preenchido
       JTable tabela = new JTable(modeloTabela);
       // Adicionar a tabela a um JScrollPane e exibi-la
       JScrollPane scrollPane = new JScrollPane(tabela);
       getContentPane().add(scrollPane);
       setSize(600, 400);
       setVisible(true);
       setLocationRelativeTo(null);
   }
   public static void main(String[] args) {
       // Criar uma instância da classe e exibir a janela
       new ListagemFrios();
   }
}



